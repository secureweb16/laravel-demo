<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-default">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="price_box ">
                                  <div class="mepr-price-box-head">
                                    <div class="price_title">$70 </div>
                                    </div>
                                    <div class="plan_cont">
                                        <p>Test 1</p>
                                        <p>Test 2</p>
                                        <p>Test 3</p>
                                    </div>

                                  <div class="buyNow">
                                    <?php
                                        $currentusercharge = App\Charge::where(['amount' => 70, 'userid' => Auth::user()->id])->first();
                                    ?>
                                   <?php if( count( $currentusercharge ) == 0 ): ?> 
                                    <form class="form-horizontal " role="form" method="POST" action="<?php echo e(url('/home')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="submit" class="customButton" value="Buy Now"/>
                                        <input type="hidden" name="amount" value="7000" >
                                        <div class="hidescript">
                                            <script
                                                src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                data-key="<?php echo e($_ENV['STRIPE_KEY']); ?>"
                                                data-amount="7000"
                                                data-name="Billing Form 1"
                                                data-description="Single Charge Payment 1"
                                                data-image=""
                                                data-locale="auto">
                                            </script>
                                        </div>
                                    </form>
                                     <?php else: ?>
                                        <button class="customButton" > Already paid </button>
                                     <?php endif; ?>
                                  </div>
                            </div>
                        </div>
                        <div class="col-md-6">                            
                            <div class="price_box ">
                                <div class="mepr-price-box-head">
                                    <div class="price_title">$90 </div>
                                </div>
                                <div class="plan_cont">
                                    <p>Test 1</p>
                                    <p>Test 2</p>
                                    <p>Test 3</p>
                                </div>
                                <?php
                                    $currentusercharge = App\Charge::where(['amount' => 90, 'userid' => Auth::user()->id])->first();
                                ?>
                               <?php if( count( $currentusercharge ) == 0 ): ?> 
                                    <div class="buyNow">
                                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/home')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="submit" class="customButton" value="Buy Now"/>
                                            <input type="hidden" name="amount" value="9000" >
                                            <div class="hidescript">
                                                <script
                                                    src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                    data-key="<?php echo e($_ENV['STRIPE_KEY']); ?>"
                                                    data-amount="9000"
                                                    data-name="Billing Form 2"
                                                    data-description="Single Charge Payment 2"
                                                    data-image=""
                                                    data-locale="auto">
                                                </script>
                                            </div>
                                        </form>
                                    </div> 
                                 <?php else: ?>
                                    <button class="customButton" > Already paid </button>
                                 <?php endif; ?>
                            </div> 
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>